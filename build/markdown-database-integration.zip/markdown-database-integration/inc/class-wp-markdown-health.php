<?php
/**
 * Runtime health checks and safe db.php drop-in repair for MDI.
 *
 * @package Markdown_Database_Integration
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wp-markdown-backend-capabilities.php';

class WP_Markdown_Health {

	/**
	 * Diagnose the MDI runtime and drop-in state.
	 *
	 * @param array $context Optional explicit values for deterministic callers.
	 * @return array Health report.
	 */
	public static function diagnose( array $context = array() ): array {
		global $wpdb;

		$mode = $context['mode'] ?? ( defined( 'MARKDOWN_DB_MODE' ) ? MARKDOWN_DB_MODE : '' );
		$mode = is_string( $mode ) ? $mode : '';

		$sqlite_runtime = $context['sqlite_runtime'] ?? ( class_exists( 'WP_SQLite_DB' ) && $wpdb instanceof WP_SQLite_DB );
		$backend        = $context['backend_capabilities'] ?? ( $sqlite_runtime || ( defined( 'MARKDOWN_DB_BACKEND' ) && in_array( MARKDOWN_DB_BACKEND, array( 'mysql-content', 'mysql-full' ), true ) ) ? WP_Markdown_Backend_Resolver::resolve() : new WP_Markdown_Backend_Capabilities( 'none' ) );
		if ( ! $backend instanceof WP_Markdown_Backend_Capabilities ) {
			throw new InvalidArgumentException( 'backend_capabilities must be a WP_Markdown_Backend_Capabilities instance.' );
		}
		foreach ( $context['required_capabilities'] ?? array() as $capability ) {
			try {
				$backend->require( (string) $capability );
			} catch ( WP_Markdown_Unsupported_Backend_Capability $error ) {
				return self::with_backend( array(
					'status'     => 'unsupported_backend_capability',
					'healthy'    => false,
					'mode'       => $mode,
					'message'    => $error->getMessage(),
					'diagnostic' => $error->get_diagnostic(),
				), $backend );
			}
		}
		if ( ! $sqlite_runtime ) {
			if ( 'mysql-full' === $backend->get_backend() ) {
				$boundary = $context['mysql_full_boundary'] ?? ( class_exists( 'WP_Markdown_MySQL_WPDB' ) && $wpdb instanceof WP_Markdown_MySQL_WPDB );
				$sink = $context['mysql_full_sink'] ?? ( is_object( $wpdb ?? null ) && method_exists( $wpdb, 'has_mutation_sink' ) && $wpdb->has_mutation_sink() );
				$diagnostic = $context['mysql_full_diagnostic'] ?? ( $GLOBALS['markdown_db_mysql_full_diagnostic'] ?? null );
				if ( is_array( $diagnostic ) && str_starts_with( (string) ( $diagnostic['code'] ?? '' ), 'markdown_db_mysql_full_bootstrap_' ) ) {
					return self::with_backend( array( 'status' => 'mysql_full_bootstrap_failed', 'healthy' => false, 'mode' => $mode, 'message' => (string) ( $diagnostic['message'] ?? 'mysql-full bootstrap failed.' ), 'diagnostic' => $diagnostic ), $backend );
				}
				if ( ! $boundary ) {
					return self::with_backend( array( 'status' => 'mysql_full_dropin_required', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-full requires the MDI-owned db.php wpdb boundary; normal plugin bootstrap cannot observe early queries.' ), $backend );
				}
				if ( ! $sink ) {
					return self::with_backend( array( 'status' => 'mysql_full_outbox_required', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-full has no durable mutation outbox, so capture is disabled.' ), $backend );
				}
				if ( is_array( $diagnostic ) && 'markdown_db_mysql_full_observer_failed' === ( $diagnostic['code'] ?? null ) ) {
					return self::with_backend( array( 'status' => 'mysql_full_observer_failed', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-full mutation capture encountered a sink failure.', 'diagnostic' => $diagnostic ), $backend );
				}
				$outbox = $context['mysql_full_outbox'] ?? ( $GLOBALS['markdown_db_mysql_outbox'] ?? null );
				try {
					$outbox_diagnostics = $context['mysql_full_outbox_diagnostics'] ?? ( is_object( $outbox ) && method_exists( $outbox, 'diagnostics' ) ? $outbox->diagnostics() : null );
				} catch ( Throwable $error ) {
					$outbox_diagnostics = array( 'ready' => false, 'error' => $error->getMessage() );
				}
				if ( ! is_array( $outbox_diagnostics ) || empty( $outbox_diagnostics['ready'] ) ) {
					return self::with_backend( array( 'status' => 'mysql_full_outbox_unavailable', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-full could not validate its durable outbox schema.', 'outbox' => $outbox_diagnostics ), $backend );
				}
				$drain = $context['mysql_full_semantic_drain'] ?? ( $GLOBALS['markdown_db_mysql_semantic_drain'] ?? null );
				try { $drain_diagnostics = is_object( $drain ) && method_exists( $drain, 'diagnostics' ) ? $drain->diagnostics() : array( 'ready' => false ); } catch ( Throwable $error ) { $drain_diagnostics = array( 'ready' => false, 'error' => $error->getMessage() ); }
				if ( empty( $drain_diagnostics['ready'] ) || empty( $drain_diagnostics['planner_ready'] ) ) {
					return self::with_backend( array( 'status' => 'mysql_full_semantic_drain_unavailable', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-full durable capture is ready but semantic intent planning is unavailable.', 'outbox' => $outbox_diagnostics, 'semantic_drain' => $drain_diagnostics ), $backend );
				}
				$publisher_ready = $context['mysql_full_publisher_ready'] ?? ( class_exists( 'WP_Markdown_MySQL_Full_Runtime' ) && WP_Markdown_MySQL_Full_Runtime::is_active() );
				if ( ! $publisher_ready ) {
					return self::with_backend( array( 'status' => 'mysql_full_canonical_publisher_unavailable', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-full semantic intent planning is ready but canonical publication is unavailable.', 'outbox' => $outbox_diagnostics, 'semantic_drain' => $drain_diagnostics ), $backend );
				}
				return self::with_backend( array( 'status' => 'mysql_full_canonical_publication_ready', 'healthy' => true, 'mode' => $mode, 'message' => 'MDI mysql-full durable canonical publication is ready. Cold reconstruction and full-primary stability remain later slices.', 'outbox' => $outbox_diagnostics, 'semantic_drain' => $drain_diagnostics ), $backend );
			}
			if ( 'mysql-content' === $backend->get_backend() ) {
				$dropin_loaded = $context['dropin_loaded'] ?? ( defined( 'MARKDOWN_DB_RETAINED_DROPIN' ) || ( defined( 'MARKDOWN_DB_DROPIN' ) && MARKDOWN_DB_DROPIN ) );
				if ( $dropin_loaded ) {
					return self::with_backend( array( 'status' => 'mysql_content_dropin_migration_required', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-content runs on normal MySQL without db.php. Remove the MDI SQLite db.php drop-in, restart PHP, then rerun markdown-db doctor.' ), $backend );
				}
				$managed_types = $context['managed_post_types'] ?? ( defined( 'MARKDOWN_DB_MANAGED_POST_TYPES' ) ? MARKDOWN_DB_MANAGED_POST_TYPES : '' );
				if ( ! is_string( $managed_types ) || '' === trim( $managed_types ) ) {
					return self::with_backend( array( 'status' => 'not_configured', 'healthy' => false, 'mode' => $mode, 'message' => 'mysql-content requires explicitly configured MARKDOWN_DB_MANAGED_POST_TYPES.' ), $backend );
				}
				if ( ! $backend->supports( 'content_mutation_capture' ) || ! $backend->supports( 'cold_reconstruction' ) || ! $backend->supports( 'explicit_flush' ) || ! $backend->supports( 'changed_path_receipts' ) ) {
					return self::with_backend( array( 'status' => 'unsupported_backend_capability', 'healthy' => false, 'mode' => $mode, 'message' => 'The mysql-content backend declaration is incomplete.' ), $backend );
				}
				return self::with_backend( array( 'status' => 'healthy', 'healthy' => true, 'mode' => $mode, 'message' => 'MDI MySQL content-primary lifecycle runtime is active without a db.php drop-in.' ), $backend );
			}
			return self::with_backend( array(
				'status'  => 'not_applicable',
				'healthy' => true,
				'mode'    => $mode,
				'message' => 'MDI drop-in health is not applicable to this non-SQLite runtime. Import/export remains available.',
			), $backend );
		}

		if ( ! in_array( $mode, array( 'primary', 'mirror' ), true ) ) {
			return self::with_backend( array(
				'status'  => 'not_configured',
				'healthy' => true,
				'mode'    => $mode,
				'message' => 'No MDI primary or mirror mode is configured.',
			), $backend );
		}

		$dropin_loaded = $context['dropin_loaded'] ?? ( defined( 'MARKDOWN_DB_DROPIN' ) && MARKDOWN_DB_DROPIN );
		$install_fallback = $context['install_fallback'] ?? ( defined( 'MARKDOWN_DB_INSTALL_FALLBACK' ) && MARKDOWN_DB_INSTALL_FALLBACK );
		$runtime_classes = $context['runtime_classes'] ?? array(
			class_exists( 'WP_Markdown_DB' ),
			class_exists( 'WP_Markdown_Write_Engine' ),
			class_exists( 'WP_Markdown_Loader' ),
			class_exists( 'WP_Markdown_Storage' ),
		);
		$runtime_loaded = ! in_array( false, $runtime_classes, true );
		$markdown_runtime = $context['markdown_runtime'] ?? ( class_exists( 'WP_Markdown_DB' ) && $wpdb instanceof WP_Markdown_DB );

		if ( 'primary' === $mode && $dropin_loaded && $install_fallback ) {
			return self::with_backend( array(
				'status'  => 'install_fallback',
				'healthy' => true,
				'mode'    => $mode,
				'message' => 'MDI primary install fallback is active until WordPress installation completes.',
			), $backend );
		}

		if ( $dropin_loaded && $runtime_loaded && $markdown_runtime ) {
			return self::with_backend( array(
				'status'  => 'healthy',
				'healthy' => true,
				'mode'    => $mode,
				'message' => 'MDI drop-in and runtime classes are active.',
			), $backend );
		}

		return self::with_backend( array(
			'status'  => 'dropin_missing_or_replaced',
			'healthy' => false,
			'mode'    => $mode,
			'message' => 'MDI ' . $mode . ' mode is configured, but the MDI db.php drop-in and runtime are not active.',
		), $backend );
	}

	/**
	 * Add the backend contract without changing existing health fields.
	 *
	 * @param array $report Health report.
	 */
	private static function with_backend( array $report, WP_Markdown_Backend_Capabilities $backend ): array {
		$report['backend'] = $backend->report();
		return $report;
	}

	/**
	 * Install or repair the MDI db.php drop-in.
	 *
	 * @param array $options Repair options.
	 * @return array Repair report.
	 */
	public static function repair_dropin( array $options = array() ): array {
		$source      = $options['source'] ?? ( defined( 'MARKDOWN_DB_PLUGIN_DIR' ) ? MARKDOWN_DB_PLUGIN_DIR . 'db.php' : '' );
		$destination = $options['destination'] ?? ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/db.php' : '' );
		$force       = ! empty( $options['force'] );

		if ( ! is_string( $source ) || ! is_readable( $source ) || ! self::is_mdi_dropin( $source ) ) {
			return self::repair_failure( 'The MDI source db.php is missing or invalid.' );
		}
		if ( ! is_string( $destination ) || '' === $destination ) {
			return self::repair_failure( 'A wp-content/db.php destination is required.' );
		}

		$destination_is_mdi = file_exists( $destination ) && self::is_mdi_dropin( $destination );
		if ( $destination_is_mdi && hash_equals( (string) hash_file( 'sha256', $source ), (string) hash_file( 'sha256', $destination ) ) ) {
			return array(
				'success' => true,
				'changed' => false,
				'status'  => 'already_installed',
				'message' => 'The MDI db.php drop-in is already installed. Restart PHP or WordPress only after a changed repair.',
			);
		}

		$backup = $destination . '.markdown-db-backup';
		if ( file_exists( $destination ) && ! $destination_is_mdi && ! $force ) {
			return self::repair_failure( 'Refusing to overwrite an unrelated db.php. Re-run with --force to back it up to ' . $backup . ' first.' );
		}
		if ( file_exists( $destination ) && ! $destination_is_mdi && file_exists( $backup ) ) {
			return self::repair_failure( 'Refusing to overwrite an unrelated db.php because the deterministic backup path already exists: ' . $backup );
		}
		if ( ! is_dir( dirname( $destination ) ) || ! is_writable( dirname( $destination ) ) ) {
			return self::repair_failure( 'The db.php destination directory is not writable.' );
		}

		$created_backup = file_exists( $destination ) && ! $destination_is_mdi;
		if ( $created_backup && ! rename( $destination, $backup ) ) {
			return self::repair_failure( 'Could not create the backup: ' . $backup );
		}

		$temporary = $destination . '.markdown-db-tmp-' . bin2hex( random_bytes( 8 ) );
		if ( ! copy( $source, $temporary ) || ! rename( $temporary, $destination ) ) {
			if ( file_exists( $temporary ) ) {
				unlink( $temporary );
			}
			if ( $created_backup && file_exists( $backup ) ) {
				rename( $backup, $destination );
			}
			return self::repair_failure( 'Could not install the MDI db.php drop-in.' );
		}

		return array(
			'success' => true,
			'changed' => true,
			'status'  => $destination_is_mdi ? 'updated' : 'installed',
			'backup'  => $created_backup && file_exists( $backup ) ? $backup : '',
			'message' => ( $destination_is_mdi ? 'Updated' : 'Installed' ) . ' the MDI db.php drop-in. Restart PHP or WordPress before checking health because db.php loads before plugins.',
		);
	}

	private static function is_mdi_dropin( string $path ): bool {
		$contents = file_get_contents( $path );
		return is_string( $contents ) && str_contains( $contents, '@studio-keep' ) && str_contains( $contents, 'MARKDOWN_DB_DROPIN' );
	}

	private static function repair_failure( string $message ): array {
		return array(
			'success' => false,
			'changed' => false,
			'message' => $message,
		);
	}
}
